<?php
function connect(){
	return oci_connect('cs5226','cs5226','//172.17.193.28:1521/CS5226');
}
?>